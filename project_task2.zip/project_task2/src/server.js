require('dotenv').config()
const express = require('express')
const cors = require('cors')
const db = require('./config/database')

const app = express()
const port = process.env.PORT || 3000

app.use(cors())
app.use(express.json())

app.get('/', (_, res) => res.json({ msg: 'Event Booking API v1' }))

app.use('/api/auth', require('./routes/auth.routes'))
app.use('/api/events', require('./routes/event.routes'))
app.use('/api/bookings', require('./routes/booking.routes'))

app.use(require('./middleware/error.middleware'))

db().then(() => {
  app.listen(port, () => console.log(`🚀 Server up on ${port}`))
}).catch(err => {
  console.error('Failed to start:', err)
  process.exit(1)
})
