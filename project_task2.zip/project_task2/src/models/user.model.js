const bcrypt = require('bcrypt')
const { db } = require('../config/database')

class User {
  static async findByEmail(email) {
    return db.users.find(u => u.email.toLowerCase() === email.toLowerCase())
  }

  static async findById(id) {
    return db.users.find(u => u.id === id)
  }

  static async create(data) {
    // Validate email
    if (!data.email?.match(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/)) {
      throw new Error('Invalid email')
    }

    // Check unique email
    if (await this.findByEmail(data.email)) {
      throw new Error('Email already exists')
    }

    // Hash password
    const salt = await bcrypt.genSalt(10)
    const pwd = await bcrypt.hash(data.password, salt)

    const user = {
      id: Date.now().toString(),
      email: data.email.toLowerCase(),
      pwd,
      role: data.role || 'user',
      createdAt: new Date(),
      updatedAt: new Date()
    }

    db.users.push(user)
    const { pwd: _, ...userWithoutPwd } = user
    return userWithoutPwd
  }

  static async validatePassword(user, password) {
    return bcrypt.compare(password, user.pwd)
  }
}

module.exports = User
