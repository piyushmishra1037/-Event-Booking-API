const { db } = require('../config/database')

class Event {
  static async findById(id) {
    return db.events.find(e => e.id === id)
  }

  static async find(filter = {}) {
    return db.events.filter(e => {
      for (let key in filter) {
        if (e[key] !== filter[key]) return false
      }
      return true
    })
  }

  static async create(data) {
    const event = {
      id: Date.now().toString(),
      ...data,
      available: data.seats,
      createdAt: new Date(),
      updatedAt: new Date()
    }
    db.events.push(event)
    return event
  }

  static async findByIdAndUpdate(id, data) {
    const idx = db.events.findIndex(e => e.id === id)
    if (idx === -1) return null

    db.events[idx] = {
      ...db.events[idx],
      ...data,
      updatedAt: new Date()
    }
    return db.events[idx]
  }

  static async findByIdAndDelete(id) {
    const idx = db.events.findIndex(e => e.id === id)
    if (idx === -1) return null

    const [event] = db.events.splice(idx, 1)
    return event
  }
}

module.exports = Event
