const { db } = require('../config/database')
const Event = require('./event.model')

class Booking {
  static async findById(id) {
    return db.bookings.find(b => b.id === id)
  }

  static async findByUser(userId) {
    return db.bookings.filter(b => b.userId === userId)
  }

  static async create(data) {
    const event = await Event.findById(data.eventId)
    if (!event) throw new Error('Event not found')
    if (event.available < data.seats) throw new Error('Not enough seats')

    const booking = {
      id: Date.now().toString(),
      userId: data.userId,
      eventId: data.eventId,
      seats: data.seats,
      status: 'confirmed',
      createdAt: new Date(),
      updatedAt: new Date()
    }

    // Update event available seats
    await Event.findByIdAndUpdate(event.id, {
      available: event.available - data.seats
    })

    db.bookings.push(booking)
    return booking
  }

  static async cancel(id) {
    const idx = db.bookings.findIndex(b => b.id === id)
    if (idx === -1) return null

    const booking = db.bookings[idx]
    if (booking.status === 'cancelled') return booking

    // Restore event seats
    const event = await Event.findById(booking.eventId)
    if (event) {
      await Event.findByIdAndUpdate(event.id, {
        available: event.available + booking.seats
      })
    }

    booking.status = 'cancelled'
    booking.updatedAt = new Date()
    return booking
  }
}

module.exports = Booking;
