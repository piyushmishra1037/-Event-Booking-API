const { validationResult } = require('express-validator')

const validate = (req, res, next) => {
  const errs = validationResult(req)
  
  if (errs.isEmpty()) return next()
  
  res.status(400).json({
    msg: 'Check your input',
    errors: errs.array().map(({ param: field, msg }) => ({ field, msg }))
  })
}

module.exports = validate
