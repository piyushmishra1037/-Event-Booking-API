const jwt = require('jsonwebtoken')
const User = require('../models/user.model')

const getToken = req => {
  const auth = req.header('Authorization')?.replace('Bearer ', '')
  if (!auth) throw 'No token'
  return auth
}

exports.auth = async (req, res, next) => {
  try {
    const token = getToken(req)
    const decoded = jwt.verify(token, process.env.JWT_KEY)
    
    const user = await User.findById(decoded.id)
    if (!user) throw 'Invalid user'

    const { pwd, ...userData } = user
    req.user = userData
    next()
  } catch (err) {
    res.status(401).json({ msg: 'Invalid token' })
  }
}

exports.admin = (req, res, next) => {
  if (req.user.role !== 'admin') {
    return res.status(403).json({ msg: 'Admin only' })
  }
  next()
}
