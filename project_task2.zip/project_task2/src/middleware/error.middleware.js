const handleError = (err, req, res, next) => {
  console.error('❌ Error:', err.message)

  switch(err.name) {
    case 'ValidationError':
      return res.status(400).json({
        msg: 'Invalid data',
        errors: err.errors.map(e => ({ 
          field: e.path, 
          msg: e.message 
        }))
      })

    case 'MongoError':
      if (err.code === 11000) {
        return res.status(400).json({
          msg: 'Already exists',
          field: Object.keys(err.keyValue)[0]
        })
      }
      break

    case 'CastError':
      return res.status(400).json({
        msg: 'Invalid ID format'
      })
  }

  res.status(500).json({ 
    msg: 'Oops! Something went wrong' 
  })
}

module.exports = handleError
