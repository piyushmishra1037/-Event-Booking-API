const { Router } = require('express')
const { body, query } = require('express-validator')
const ctrl = require('../controllers/event.controller')
const auth = require('../middleware/auth.middleware')
const validate = require('../middleware/validate.middleware')

const router = Router()

const validateEvent = [
  body('title').trim().notEmpty(),
  body('desc').trim().notEmpty(),
  body('when').isISO8601(),
  body('where').trim().notEmpty(),
  body('seats').isInt({ min: 1 }),
  validate
]

const validateSearch = [
  query('page').optional().isInt({ min: 1 }),
  query('limit').optional().isInt({ min: 1, max: 50 }),
  query('date').optional().isISO8601(),
  query('loc').optional().isString(),
  validate
]

router
  .get('/', validateSearch, ctrl.getEvents)
  .get('/:id', ctrl.getEventById)
  
  .post('/', 
    auth.authenticate,
    auth.isAdmin,
    validateEvent,
    ctrl.createEvent
  )
  
  .put('/:id',
    auth.authenticate, 
    auth.isAdmin,
    validateEvent,
    ctrl.updateEvent
  )
  
  .delete('/:id',
    auth.authenticate,
    auth.isAdmin,
    ctrl.deleteEvent
  )

module.exports = router
