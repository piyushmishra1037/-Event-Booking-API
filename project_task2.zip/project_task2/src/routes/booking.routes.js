const router = require('express').Router();
const bookingController = require('../controllers/booking.controller');
const { authenticate } = require('../middleware/auth.middleware');
const { param } = require('express-validator');
const validate = require('../middleware/validate.middleware');

router.use(authenticate); // All booking routes require authentication

router.post('/:eventId',
  [
    param('eventId').isUUID().withMessage('Invalid event ID'),
    validate
  ],
  bookingController.createBooking
);

router.get('/', bookingController.getUserBookings);

router.delete('/:bookingId',
  [
    param('bookingId').isUUID().withMessage('Invalid booking ID'),
    validate
  ],
  bookingController.cancelBooking
);

module.exports = router;
