// In-memory database
const db = {
  users: [],
  events: [],
  bookings: []
}

const connect = async () => {
  console.log('🌿 In-memory DB initialized')
  return Promise.resolve()
}

module.exports = {
  connect,
  db
}
