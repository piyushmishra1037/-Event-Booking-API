const Event = require('../models/event.model')

const handleError = (res, err) => {
  console.error('Event error:', err)
  res.status(500).json({ msg: 'Something went wrong' })
}

const findEvent = async (id) => {
  const event = await Event.findById(id)
  if (!event) throw { status: 404, msg: 'Event not found' }
  return event
}

exports.getEvents = async (req, res) => {
  try {
    const pg = +req.query.page || 1
    const size = +req.query.limit || 10
    
    let events = await Event.find()
    
    // Filter by date
    if (req.query.date) {
      const date = new Date(req.query.date)
      const nextDay = new Date(date)
      nextDay.setDate(nextDay.getDate() + 1)
      
      events = events.filter(e => {
        return e.when >= date && e.when < nextDay
      })
    }
    
    // Filter by location
    if (req.query.loc) {
      const loc = req.query.loc.toLowerCase()
      events = events.filter(e => {
        return e.where.toLowerCase().includes(loc)
      })
    }

    // Sort by date
    events.sort((a, b) => a.when - b.when)

    // Paginate
    const start = (pg - 1) * size
    const end = start + size
    const data = events.slice(start, end)

    res.json({
      data,
      meta: {
        total: events.length,
        page: pg,
        pages: Math.ceil(events.length / size)
      }
    })
  } catch (err) {
    handleError(res, err)
  }
}

exports.getEventById = async (req, res) => {
  try {
    const event = await findEvent(req.params.id)
    res.json(event)
  } catch (err) {
    if (err.status === 404) return res.status(404).json({ msg: err.msg })
    handleError(res, err)
  }
}

exports.createEvent = async (req, res) => {
  try {
    const { title, desc, when, where, seats } = req.body
    
    const event = await Event.create({
      title,
      desc,
      when: new Date(when),
      where,
      seats
    })

    res.status(201).json(event)
  } catch (err) {
    handleError(res, err)
  }
}

exports.updateEvent = async (req, res) => {
  try {
    const event = await findEvent(req.params.id)
    const { title, desc, when, where, seats } = req.body
    
    const diff = seats - event.seats
    const newAvail = event.available + diff
    
    if (newAvail < 0) {
      return res.status(400).json({ msg: 'Not enough seats available' })
    }

    const updated = await Event.findByIdAndUpdate(event.id, {
      title,
      desc,
      when: new Date(when),
      where,
      seats,
      available: newAvail
    })

    res.json(updated)
  } catch (err) {
    if (err.status === 404) return res.status(404).json({ msg: err.msg })
    handleError(res, err)
  }
}

exports.deleteEvent = async (req, res) => {
  try {
    const event = await findEvent(req.params.id)
    await Event.findByIdAndDelete(event.id)
    res.status(204).end()
  } catch (err) {
    if (err.status === 404) return res.status(404).json({ msg: err.msg })
    handleError(res, err)
  }
}
