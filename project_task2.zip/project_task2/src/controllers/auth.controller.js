const User = require('../models/user.model')
const jwt = require('jsonwebtoken')

exports.signup = async (req, res) => {
  try {
    const { email, password } = req.body
    if (!email || !password) {
      return res.status(400).json({ msg: 'Missing required fields' })
    }

    const user = await User.create({ email, password })
    
    const token = jwt.sign(
      { id: user.id, role: user.role },
      process.env.JWT_KEY,
      { expiresIn: process.env.JWT_EXPIRES || '24h' }
    )

    res.status(201).json({ token })
  } catch (err) {
    if (err.message === 'Email already exists') {
      return res.status(400).json({ msg: 'Email taken' })
    }
    if (err.message === 'Invalid email') {
      return res.status(400).json({ msg: 'Invalid email format' })
    }
    res.status(500).json({ msg: 'Registration failed' })
  }
}

exports.login = async (req, res) => {
  try {
    const { email, password } = req.body
    if (!email || !password) {
      return res.status(400).json({ msg: 'Missing credentials' })
    }

    const user = await User.findByEmail(email)
    if (!user) {
      return res.status(401).json({ msg: 'Invalid credentials' })
    }

    const valid = await User.validatePassword(user, password)
    if (!valid) {
      return res.status(401).json({ msg: 'Invalid credentials' })
    }

    const token = jwt.sign(
      { id: user.id, role: user.role },
      process.env.JWT_KEY,
      { expiresIn: process.env.JWT_EXPIRES || '24h' }
    )

    res.json({ token })
  } catch (err) {
    res.status(500).json({ msg: 'Login failed' })
  }
}
