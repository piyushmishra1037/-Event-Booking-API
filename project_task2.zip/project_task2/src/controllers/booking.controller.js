const { Booking, Event, User } = require('../models');
const { sequelize } = require('../models');

exports.createBooking = async (req, res, next) => {
  const t = await sequelize.transaction();
  
  try {
    const event = await Event.findByPk(req.params.eventId, { 
      lock: t.LOCK.UPDATE,
      transaction: t 
    });

    if (!event) {
      await t.rollback();
      return res.status(404).json({ message: 'Event not found' });
    }

    if (event.availableSeats < 1) {
      await t.rollback();
      return res.status(400).json({ message: 'No seats available' });
    }

    // Create booking and update seats atomically
    const booking = await Booking.create({
      userId: req.user.id,
      eventId: event.id
    }, { transaction: t });

    await event.update({
      availableSeats: event.availableSeats - 1
    }, { transaction: t });

    await t.commit();

    res.status(201).json(booking);
  } catch (err) {
    await t.rollback();
    next(err);
  }
};

exports.getUserBookings = async (req, res, next) => {
  try {
    const bookings = await Booking.findAll({
      where: { 
        userId: req.user.id,
        status: 'active'  // Only show active bookings
      },
      include: [{
        model: Event,
        as: 'event',
        attributes: ['title', 'dateTime', 'location']
      }]
    });

    res.json(bookings);
  } catch (err) {
    next(err);
  }
};

exports.cancelBooking = async (req, res, next) => {
  const t = await sequelize.transaction();
  
  try {
    const booking = await Booking.findOne({
      where: {
        id: req.params.bookingId,
        userId: req.user.id,
        status: 'active'
      },
      transaction: t
    });

    if (!booking) {
      await t.rollback();
      return res.status(404).json({ message: 'Active booking not found' });
    }

    // Update booking status and increase available seats
    await booking.update({ status: 'cancelled' }, { transaction: t });
    
    await Event.increment('availableSeats', { 
      by: 1,
      where: { id: booking.eventId },
      transaction: t
    });

    await t.commit();
    res.status(204).send();
  } catch (err) {
    await t.rollback();
    next(err);
  }
};
