# Event Booking System API

A RESTful API for managing events and bookings built with Node.js, Express, and PostgreSQL.

## Features

- User authentication with JWT
- Role-based access control (user/admin)
- Event management (CRUD operations)
- Booking system with seat management
- Input validation
- Error handling
- Pagination and filtering for events

## Prerequisites

- Node.js (v14 or higher)
- PostgreSQL
- npm or yarn

## Setup

1. Clone the repository
2. Install dependencies:
   ```bash
   npm install
   ```
3. Copy `.env.sample` to `.env` and update the values:
   ```bash
   cp .env.sample .env
   ```
4. Create a PostgreSQL database and update the database configuration in `.env`

5. Start the server:
   ```bash
   npm run dev
   ```

## API Endpoints

### Authentication
- POST `/api/auth/register` - Register new user
- POST `/api/auth/login` - Login user

### Events
- GET `/api/events` - List all events (public)
  - Query params: page, limit, date, location
- GET `/api/events/:id` - Get event details (public)
- POST `/api/events` - Create event (admin only)
- PUT `/api/events/:id` - Update event (admin only)
- DELETE `/api/events/:id` - Delete event (admin only)

### Bookings
- POST `/api/bookings/:eventId` - Book an event (auth required)
- GET `/api/bookings` - Get user's bookings (auth required)
- DELETE `/api/bookings/:bookingId` - Cancel booking (auth required)

## Error Handling

The API uses consistent error response format:
```json
{
  "message": "Error message",
  "errors": [
    {
      "field": "fieldName",
      "message": "Specific error message"
    }
  ]
}
```

## Security

- Passwords are hashed using bcrypt
- JWT used for authentication
- Input validation on all endpoints
- Role-based access control
